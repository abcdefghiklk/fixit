package net.sf.jabref;


public interface CallBack {

    public void update();

}
