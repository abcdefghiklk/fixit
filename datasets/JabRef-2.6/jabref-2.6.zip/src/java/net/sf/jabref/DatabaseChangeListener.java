package net.sf.jabref;


public interface DatabaseChangeListener {
    
    public void databaseChanged(DatabaseChangeEvent e);

}
