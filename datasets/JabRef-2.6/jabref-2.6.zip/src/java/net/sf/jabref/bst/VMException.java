package net.sf.jabref.bst;

public class VMException extends RuntimeException {

	public VMException(String string) {
		super(string);
	}

}
