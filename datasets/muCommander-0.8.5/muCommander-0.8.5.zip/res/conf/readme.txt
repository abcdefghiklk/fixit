           _____                           _        
 _____ _ _|     |___ _____ _____ ___ ___ _| |___ ___
|     | | |   --| . |     |     | .'|   | . | -_|  _|
|_|_|_|___|_____|___|_|_|_|_|_|_|__,|_|_|___|___|_| 

------------------------------------
muCommander Configuration API v1.0.0
------------------------------------

The muCommander Configuration API is the library used by muCommander to handle
all of its configuration.

Please use the muCommander forums (http://www.mucommander.com/forums)
to post your questions, suggestions or bug reports.
Your feedback is important and always welcome!

Official website: http://www.mucommander.com
Copyright (C) 2002-2010 Maxence Bernard



License
-------

The muCommander Configuration API is released under the terms of the
GNU Lesser General Public License.
Please refer to the 'license.txt' file bundled with this package.


Credits
-------

Lead developers:
- Maxence Bernard
- Nicolas Rinaudo
